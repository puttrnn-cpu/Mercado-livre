import express from "express";
import dotenv from "dotenv";

dotenv.config();

const app = express();
app.use(express.json());
app.use(express.static("public"));

const PORT = process.env.PORT || 3000;
const SITE_URL = process.env.SITE_URL || `http://localhost:${PORT}`;

app.get("/api/status", (req, res) => {
  res.json({ configured: Boolean(process.env.MP_ACCESS_TOKEN) });
});

app.post("/api/checkout", async (req, res) => {
  if (!process.env.MP_ACCESS_TOKEN) {
    return res.status(500).json({ error: "MP_ACCESS_TOKEN não configurado no servidor." });
  }

  const { title = "Produto Mercadolivri", price = 10, quantity = 1 } = req.body || {};
  const unitPrice = Number(price);
  const qty = Number(quantity);

  if (!Number.isFinite(unitPrice) || unitPrice <= 0 || !Number.isInteger(qty) || qty < 1) {
    return res.status(400).json({ error: "Produto, preço ou quantidade inválidos." });
  }

  const preference = {
    items: [{
      id: "produto-demo",
      title: String(title).slice(0, 256),
      quantity: qty,
      currency_id: "BRL",
      unit_price: unitPrice
    }],
    external_reference: `mercadolivri-${Date.now()}`,
    back_urls: {
      success: `${SITE_URL}/resultado.html?status=success`,
      failure: `${SITE_URL}/resultado.html?status=failure`,
      pending: `${SITE_URL}/resultado.html?status=pending`
    },
    auto_return: "approved"
  };

  try {
    const response = await fetch("https://api.mercadopago.com/checkout/preferences", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${process.env.MP_ACCESS_TOKEN}`
      },
      body: JSON.stringify(preference)
    });

    const data = await response.json();

    if (!response.ok) {
      console.error("Mercado Pago:", data);
      return res.status(502).json({
        error: "O Mercado Pago recusou a criação do pagamento.",
        details: data
      });
    }

    res.json({
      checkout_url: data.init_point,
      preference_id: data.id
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Erro de conexão com o Mercado Pago." });
  }
});

app.get("/api/health", (req, res) => res.json({ ok: true }));

app.listen(PORT, "0.0.0.0", () => {
  console.log(`Mercadolivri rodando na porta ${PORT}`);
});
