# Mercadolivri — receber pagamentos

Projeto simples para colocar o Mercadolivri no ar e testar pagamentos pelo Mercado Pago.

## Segurança
- Nunca coloque o Access Token no HTML, JavaScript do navegador ou GitHub.
- Configure `MP_ACCESS_TOKEN` nas variáveis de ambiente do servidor.
- O arquivo `.env` não deve ser enviado ao GitHub.

## Local
1. Instale Node.js.
2. Copie `.env.example` para `.env`.
3. Coloque o Access Token de teste no `.env`.
4. Rode `npm install`.
5. Rode `npm start`.
6. Abra `http://localhost:3000`.

## Render
- Conecte este projeto a um repositório GitHub.
- Crie um Web Service.
- Build Command: `npm install`
- Start Command: `npm start`
- Adicione `MP_ACCESS_TOKEN` nas Environment Variables.
- Depois de receber a URL do Render, configure `SITE_URL` com essa URL.

Este primeiro passo recebe pagamentos na conta Mercado Pago associada ao Access Token. O split marketplace para repassar automaticamente parte do valor a vendedores pode ser adicionado depois.
