import express from "express";
import dotenv from "dotenv";

dotenv.config();

const app = express();
const PORT = process.env.PORT || 3000;
const SITE_URL = process.env.SITE_URL || `http://localhost:${PORT}`;

app.use(express.json());

const html = `<!doctype html>
<html lang="pt-BR">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Mercadolivri</title>
<style>
body{font-family:Arial,sans-serif;background:#f5f5f5;margin:0;color:#222}
.card{max-width:500px;margin:50px auto;padding:25px;background:#fff;border-radius:16px;box-shadow:0 4px 20px #0001}
input,button{width:100%;box-sizing:border-box;padding:14px;margin:8px 0;border-radius:10px}
input{border:1px solid #ccc}button{border:0;background:#ffd600;font-weight:700;font-size:16px}
#msg{margin-top:12px}
</style></head>
<body><div class="card">
<h1>Mercadolivri</h1><p>Pagamento de teste com Mercado Pago</p>
<input id="title" value="Produto de teste">
<input id="price" type="number" min="1" step="0.01" value="10">
<button onclick="pagar()">Pagar com Mercado Pago</button>
<div id="msg"></div>
</div>
<script>
async function pagar(){
 const msg=document.getElementById("msg"); msg.textContent="Criando pagamento...";
 try{
  const r=await fetch("/api/checkout",{method:"POST",headers:{"Content-Type":"application/json"},
   body:JSON.stringify({title:document.getElementById("title").value,price:Number(document.getElementById("price").value)})});
  const d=await r.json(); if(!r.ok) throw new Error(d.error||"Erro");
  location.href=d.checkout_url;
 }catch(e){msg.textContent=e.message}
}
</script></body></html>`;

app.get("/", (req,res) => res.type("html").send(html));

app.post("/api/checkout", async (req,res) => {
  if (!process.env.MP_ACCESS_TOKEN)
    return res.status(500).json({error:"Access Token do Mercado Pago ainda não foi configurado no servidor."});

  const title = String(req.body?.title || "Produto Mercadolivri").slice(0,256);
  const price = Number(req.body?.price);
  if (!Number.isFinite(price) || price <= 0)
    return res.status(400).json({error:"Informe um preço válido."});

  const preference = {
    items:[{id:"produto-demo",title,quantity:1,currency_id:"BRL",unit_price:price}],
    external_reference:`mercadolivri-${Date.now()}`,
    back_urls:{
      success:`${SITE_URL}/?status=success`,
      failure:`${SITE_URL}/?status=failure`,
      pending:`${SITE_URL}/?status=pending`
    },
    auto_return:"approved"
  };

  try{
    const r=await fetch("https://api.mercadopago.com/checkout/preferences",{
      method:"POST",
      headers:{"Content-Type":"application/json","Authorization":`Bearer ${process.env.MP_ACCESS_TOKEN}`},
      body:JSON.stringify(preference)
    });
    const d=await r.json();
    if(!r.ok) return res.status(502).json({error:"O Mercado Pago recusou a criação do pagamento.",details:d});
    res.json({checkout_url:d.init_point});
  }catch(e){
    res.status(500).json({error:"Erro de conexão com o Mercado Pago."});
  }
});

app.listen(PORT,"0.0.0.0",()=>console.log(`Mercadolivri na porta ${PORT}`));
